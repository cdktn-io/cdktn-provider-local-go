/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface FileConfig extends cdktn.TerraformMetaArguments {
    /**
    * Content to store in the file, expected to be a UTF-8 encoded string.
    *  Conflicts with `sensitive_content`, `content_base64` and `source`.
    *  Exactly one of these four arguments must be specified.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/local/2.9.0/docs/resources/file#content File#content}
    */
    readonly content?: string;
    /**
    * Content to store in the file, expected to be binary encoded as base64 string.
    *  Conflicts with `content`, `sensitive_content` and `source`.
    *  Exactly one of these four arguments must be specified.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/local/2.9.0/docs/resources/file#content_base64 File#content_base64}
    */
    readonly contentBase64?: string;
    /**
    * Permissions to set for directories created (before umask), expressed as string in
    *  [numeric notation](https://en.wikipedia.org/wiki/File-system_permissions#Numeric_notation).
    *  Default value is `"0777"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/local/2.9.0/docs/resources/file#directory_permission File#directory_permission}
    */
    readonly directoryPermission?: string;
    /**
    * Permissions to set for the output file (before umask), expressed as string in
    *  [numeric notation](https://en.wikipedia.org/wiki/File-system_permissions#Numeric_notation).
    *  Default value is `"0777"`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/local/2.9.0/docs/resources/file#file_permission File#file_permission}
    */
    readonly filePermission?: string;
    /**
    * The path to the file that will be created.
    *  Missing parent directories will be created.
    *  If the file already exists, it will be overridden with the given content.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/local/2.9.0/docs/resources/file#filename File#filename}
    */
    readonly filename: string;
    /**
    * Sensitive content to store in the file, expected to be an UTF-8 encoded string.
    *  Will not be displayed in diffs.
    *  Conflicts with `content`, `content_base64` and `source`.
    *  Exactly one of these four arguments must be specified.
    *  If in need to use _sensitive_ content, please use the [`local_sensitive_file`](./sensitive_file.html)
    *  resource instead.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/local/2.9.0/docs/resources/file#sensitive_content File#sensitive_content}
    */
    readonly sensitiveContent?: string;
    /**
    * Path to file to use as source for the one we are creating.
    *  Conflicts with `content`, `sensitive_content` and `content_base64`.
    *  Exactly one of these four arguments must be specified.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/local/2.9.0/docs/resources/file#source File#source}
    */
    readonly source?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/local/2.9.0/docs/resources/file local_file}
*/
export declare class File extends cdktn.TerraformResource {
    static readonly tfResourceType = "local_file";
    /**
    * Generates CDKTN code for importing a File resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the File to import
    * @param importFromId The id of the existing File that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/local/2.9.0/docs/resources/file#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the File to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/local/2.9.0/docs/resources/file local_file} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options FileConfig
    */
    constructor(scope: Construct, id: string, config: FileConfig);
    private _content?;
    get content(): string;
    set content(value: string);
    resetContent(): void;
    get contentInput(): string | undefined;
    private _contentBase64?;
    get contentBase64(): string;
    set contentBase64(value: string);
    resetContentBase64(): void;
    get contentBase64Input(): string | undefined;
    get contentBase64Sha256(): string;
    get contentBase64Sha512(): string;
    get contentMd5(): string;
    get contentSha1(): string;
    get contentSha256(): string;
    get contentSha512(): string;
    private _directoryPermission?;
    get directoryPermission(): string;
    set directoryPermission(value: string);
    resetDirectoryPermission(): void;
    get directoryPermissionInput(): string | undefined;
    private _filePermission?;
    get filePermission(): string;
    set filePermission(value: string);
    resetFilePermission(): void;
    get filePermissionInput(): string | undefined;
    private _filename?;
    get filename(): string;
    set filename(value: string);
    get filenameInput(): string | undefined;
    get id(): string;
    private _sensitiveContent?;
    get sensitiveContent(): string;
    set sensitiveContent(value: string);
    resetSensitiveContent(): void;
    get sensitiveContentInput(): string | undefined;
    private _source?;
    get source(): string;
    set source(value: string);
    resetSource(): void;
    get sourceInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
