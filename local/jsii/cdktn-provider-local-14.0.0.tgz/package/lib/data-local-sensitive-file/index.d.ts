/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataLocalSensitiveFileConfig extends cdktn.TerraformMetaArguments {
    /**
    * Path to the file that will be read. The data source will return an error if the file does not exist.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/local/2.9.0/docs/data-sources/sensitive_file#filename DataLocalSensitiveFile#filename}
    */
    readonly filename: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/local/2.9.0/docs/data-sources/sensitive_file local_sensitive_file}
*/
export declare class DataLocalSensitiveFile extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "local_sensitive_file";
    /**
    * Generates CDKTN code for importing a DataLocalSensitiveFile resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataLocalSensitiveFile to import
    * @param importFromId The id of the existing DataLocalSensitiveFile that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/local/2.9.0/docs/data-sources/sensitive_file#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataLocalSensitiveFile to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/local/2.9.0/docs/data-sources/sensitive_file local_sensitive_file} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataLocalSensitiveFileConfig
    */
    constructor(scope: Construct, id: string, config: DataLocalSensitiveFileConfig);
    get content(): string;
    get contentBase64(): string;
    get contentBase64Sha256(): string;
    get contentBase64Sha512(): string;
    get contentMd5(): string;
    get contentSha1(): string;
    get contentSha256(): string;
    get contentSha512(): string;
    private _filename?;
    get filename(): string;
    set filename(value: string);
    get filenameInput(): string | undefined;
    get id(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
