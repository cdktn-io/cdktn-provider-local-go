/**
 * Copyright (c) HashiCorp, Inc.
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataLocalFileConfig extends cdktf.TerraformMetaArguments {
    /**
    * Path to the file that will be read. The data source will return an error if the file does not exist.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/local/2.6.1/docs/data-sources/file#filename DataLocalFile#filename}
    */
    readonly filename: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/local/2.6.1/docs/data-sources/file local_file}
*/
export declare class DataLocalFile extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "local_file";
    /**
    * Generates CDKTF code for importing a DataLocalFile resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataLocalFile to import
    * @param importFromId The id of the existing DataLocalFile that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/local/2.6.1/docs/data-sources/file#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataLocalFile to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/local/2.6.1/docs/data-sources/file local_file} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataLocalFileConfig
    */
    constructor(scope: Construct, id: string, config: DataLocalFileConfig);
    get content(): string;
    get contentBase64(): string;
    get contentBase64Sha256(): string;
    get contentBase64Sha512(): string;
    get contentMd5(): string;
    get contentSha1(): string;
    get contentSha256(): string;
    get contentSha512(): string;
    private _filename?;
    get filename(): string;
    set filename(value: string);
    get filenameInput(): string | undefined;
    get id(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
