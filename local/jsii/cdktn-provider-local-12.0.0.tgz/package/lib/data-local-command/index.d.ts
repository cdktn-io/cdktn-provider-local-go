/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataLocalCommandConfig extends cdktn.TerraformMetaArguments {
    /**
    * Indicates that the command returning a non-zero exit code should be treated as a successful execution. Further assertions can be made of the `exit_code` value with the [`check` block](https://developer.hashicorp.com/terraform/language/block/check). Defaults to false.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/local/2.7.0/docs/data-sources/command#allow_non_zero_exit_code DataLocalCommand#allow_non_zero_exit_code}
    */
    readonly allowNonZeroExitCode?: boolean | cdktn.IResolvable;
    /**
    * Arguments to be passed to the given command. Any `null` arguments will be removed from the list.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/local/2.7.0/docs/data-sources/command#arguments DataLocalCommand#arguments}
    */
    readonly arguments?: string[];
    /**
    * Executable name to be discovered on the PATH or absolute path to executable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/local/2.7.0/docs/data-sources/command#command DataLocalCommand#command}
    */
    readonly command: string;
    /**
    * Data to be passed to the given command's standard input as a UTF-8 string. [Terraform values](https://developer.hashicorp.com/terraform/language/expressions/types) can be encoded by any Terraform encode function, for example, [`jsonencode`](https://developer.hashicorp.com/terraform/language/functions/jsonencode).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/local/2.7.0/docs/data-sources/command#stdin DataLocalCommand#stdin}
    */
    readonly stdin?: string;
    /**
    * The directory path where the command should be executed, either an absolute path or relative to the Terraform working directory. If not provided, defaults to the Terraform working directory.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/local/2.7.0/docs/data-sources/command#working_directory DataLocalCommand#working_directory}
    */
    readonly workingDirectory?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/local/2.7.0/docs/data-sources/command local_command}
*/
export declare class DataLocalCommand extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "local_command";
    /**
    * Generates CDKTN code for importing a DataLocalCommand resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataLocalCommand to import
    * @param importFromId The id of the existing DataLocalCommand that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/local/2.7.0/docs/data-sources/command#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataLocalCommand to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/local/2.7.0/docs/data-sources/command local_command} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataLocalCommandConfig
    */
    constructor(scope: Construct, id: string, config: DataLocalCommandConfig);
    private _allowNonZeroExitCode?;
    get allowNonZeroExitCode(): boolean | cdktn.IResolvable;
    set allowNonZeroExitCode(value: boolean | cdktn.IResolvable);
    resetAllowNonZeroExitCode(): void;
    get allowNonZeroExitCodeInput(): boolean | cdktn.IResolvable | undefined;
    private _arguments?;
    get arguments(): string[];
    set arguments(value: string[]);
    resetArguments(): void;
    get argumentsInput(): string[] | undefined;
    private _command?;
    get command(): string;
    set command(value: string);
    get commandInput(): string | undefined;
    get exitCode(): number;
    get stderr(): string;
    private _stdin?;
    get stdin(): string;
    set stdin(value: string);
    resetStdin(): void;
    get stdinInput(): string | undefined;
    get stdout(): string;
    private _workingDirectory?;
    get workingDirectory(): string;
    set workingDirectory(value: string);
    resetWorkingDirectory(): void;
    get workingDirectoryInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
